
<?php
namespace Grav\Plugin;

use Grav\Common\Plugin;
use Grav\Common\Grav;
use Grav\Common\Page\Page;
use Grav\Common\File\CompiledYamlFile;
use RocketTheme\Toolbox\Event\Event;
use Symfony\Component\Yaml\Yaml;

class JazykolamPlugin extends Plugin
{
    public static function getSubscribedEvents(): array
    {
        return [
            'onPluginsInitialized' => ['onPluginsInitialized', 0],
            'onTask.jazykolam.inlineSave' => ['onInlineSave', 0],
            'onTask.jazykolam.saveTranslations' => ['onSaveTranslations', 0],
            'onTask.jazykolam.exportTranslations' => ['onExportTranslations', 0],
        ];
    }

    public function onPluginsInitialized(): void
    {
        if ($this->isAdmin()) {
            $this->enable([
                'onAdminMenu' => ['onAdminMenu', 0],
                'onAdminPagesInitialized' => ['onAdminPagesInitialized', 0],
                'onAdminTwigTemplatePaths' => ['onAdminTwigTemplatePaths', 0],
            ]);
        } else {
            $this->enable([
                'onTwigExtensions' => ['onTwigExtensions', 0],
                'onOutputGenerated' => ['onOutputGenerated', 0],
            ]);
        }
    }

    public function onAdminMenu(): void
    {
        $this->grav['twig']->plugins_hooked_nav['Jazykolam'] = [
            'route' => 'jazykolam',
            'icon'  => 'fa-language',
        ];
    }

    public function onAdminPagesInitialized(Event $event): void
    {
        $admin = $this->grav['admin'] ?? null;
        if (!$admin || $admin->route !== 'jazykolam') {
            return;
        }
        $page = new Page;
        $file = __DIR__ . '/admin/pages/jazykolam.md';
        if (is_file($file)) {
            $page->init(new \SplFileInfo($file));
        }
        $page->slug('jazykolam');
        $page->template('jazykolam');
        $this->prepareAdminTranslations();
        $event['page'] = $page;
    }

    public function onAdminTwigTemplatePaths(Event $event): void
    {
        $paths = $event['paths'] ?? [];
        $paths[] = __DIR__ . '/admin/templates';
        $event['paths'] = $paths;
    }

    protected function prepareAdminTranslations(): void
    {
        require_once __DIR__ . '/classes/JazykolamTranslationManager.php';
        $grav = $this->grav;
        $manager = new JazykolamTranslationManager($grav);
        $locales = $manager->getLocales();
        $uri = $grav['uri'];
        $requested = $uri->param('locale') ?: $uri->query('locale');
        if ($requested && in_array($requested, $locales, true)) {
            $active = $requested;
        } else {
            $active = $grav['language']->getActive() ?: $locales[0];
        }
        $translations = $manager->getAllKeysForLocale($active);
        $twig = $grav['twig'];
        $twig->twig_vars['jazykolam_locales'] = $locales;
        $twig->twig_vars['jazykolam_active_locale'] = $active;
        $twig->twig_vars['jazykolam_translations'] = $translations;
    }

    public function onSaveTranslations(Event $event): void
    {
        if (!$this->isAdmin()) {
            $this->respondJson(['status' => 'error', 'message' => 'Admin only'], 403);
        }
        $request = $this->grav['request'] ?? null;
        if (!$request) {
            $this->respondJson(['status' => 'error', 'message' => 'No request'], 400);
        }
        $content = (string)$request->getContent();
        $data = $content !== '' ? json_decode($content, true) : null;
        if (!is_array($data)) {
            $data = $request->getParsedBody();
        }
        $locale = $data['locale'] ?? null;
        $translations = $data['translations'] ?? null;
        if (!$locale || !is_array($translations)) {
            $this->respondJson(['status' => 'error', 'message' => 'Invalid payload'], 400);
        }
        require_once __DIR__ . '/classes/JazykolamTranslationManager.php';
        $manager = new JazykolamTranslationManager($this->grav);
        $manager->saveOverrides($locale, $translations);
        $this->respondJson(['status' => 'ok']);
    }

    public function onExportTranslations(Event $event): void
    {
        $grav = $this->grav;
        $request = $grav['request'] ?? null;
        if (!$request) { return; }
        $format = $grav['uri']->param('format') ?: $request->get('format') ?: 'yaml';
        $locale = $grav['uri']->param('locale') ?: $request->get('locale');
        if (!$locale) {
            header('HTTP/1.1 400 Bad Request');
            echo 'Missing locale';
            exit;
        }
        require_once __DIR__ . '/classes/JazykolamTranslationManager.php';
        $manager = new JazykolamTranslationManager($grav);
        $data = $manager->getAllKeysForLocale($locale);
        $export = [];
        foreach ($data as $k => $row) {
            $export[$k] = isset($row['override']) && $row['override'] !== '' ? $row['override'] : ($row['original'] ?? '');
        }
        if ($format === 'csv') {
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="jazykolam-' . $locale . '.csv"');
            $out = fopen('php://output', 'w');
            fputcsv($out, ['key', 'value']);
            foreach ($export as $k => $v) {
                fputcsv($out, [$k, $v]);
            }
            fclose($out);
            exit;
        } else {
            header('Content-Type: application/x-yaml; charset=utf-8');
            header('Content-Disposition: attachment; filename="jazykolam.' . $locale . '.yaml"');
            echo Yaml::dump($export, 2, 2);
            exit;
        }
    }

    public function onTwigExtensions(): void
    {
        $grav = $this->grav;
        $twig = $grav['twig']->twig();
        require_once __DIR__ . '/classes/JazykolamTwigExtension.php';
        if (class_exists('\JazykolamTwigExtension')) {
            $ext = new \JazykolamTwigExtension($grav);
            $twig->addExtension($ext);
        }
    }

    public function onOutputGenerated(Event $event): void
    {
        $cfg = (array)$this->config->get('plugins.jazykolam');
        $response = $event['response'] ?? null;
        if (!$response) { return; }
        $contentType = (string)($response->headers->get('Content-Type') ?? '');
        if (stripos($contentType, 'text/html') === false) { return; }
        $html = $response->getContent();
        $changed = false;
        if (!empty($cfg['debug']['panel'])) {
            $debugHtml = '<div id="jazykolam-debug-panel" style="position:fixed;bottom:0;left:0;right:0;background:#222;color:#fff;font-size:11px;padding:4px 8px;z-index:9999;">Jazykolam debug panel active</div>';
            if (strpos($html, '</body>') !== false) {
                $html = str_replace('</body>', $debugHtml . '</body>', $html);
                $changed = true;
            }
        }
        if ($changed) {
            $response->setContent($html);
        }
    }

    public function onInlineSave(Event $event): void
    {
        if (!$this->isAdmin()) {
            $this->respondJson(['status' => 'error', 'message' => 'Admin only'], 403);
        }
        $request = $this->grav['request'] ?? null;
        if (!$request) {
            $this->respondJson(['status' => 'error', 'message' => 'No request']);
        }
        $key = $request->get('key');
        $locale = $request->get('locale');
        $value = $request->get('value');
        if (!$key || !$locale) {
            $this->respondJson(['status' => 'error', 'message' => 'Missing key or locale'], 400);
        }
        $userLangDir = $this->grav['locator']->findResource('user://languages', true, true);
        $filePath = $userLangDir . '/jazykolam-inline-' . $locale . '.yaml';
        $file = CompiledYamlFile::instance($filePath);
        $data = (array)$file->content();
        $data[$key] = $value;
        $file->save($data);
        $file->free();
        $this->respondJson(['status' => 'ok']);
    }

    protected function respondJson(array $payload, int $code = 200): void
    {
        http_response_code($code);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($payload);
        exit;
    }
}
