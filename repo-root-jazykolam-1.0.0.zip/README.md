
# Jazykolam 1.0.0

Advanced translation override manager for Grav.

## What's new
- Admin Translation Manager UI
- Export translations per locale as YAML or CSV (buttons on admin page)
- Example languages (en, cs, sk)
- Keeps 1.6.5 logic intact
