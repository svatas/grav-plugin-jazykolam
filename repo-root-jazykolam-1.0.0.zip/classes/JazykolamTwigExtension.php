
<?php
use Grav\Common\Grav;
use Twig\Extension\AbstractExtension;
use Twig\TwigFilter;

class JazykolamTwigExtension extends AbstractExtension
{
    /** @var Grav */
    protected $grav;

    public function __construct(Grav $grav)
    {
        $this->grav = $grav;
    }

    public function getName()
    {
        return 'JazykolamTwigExtension';
    }

    public function getFilters()
    {
        return [
            new TwigFilter('t', [$this, 'autoT']),
            new TwigFilter('trans', [$this, 'autoT']),
            new TwigFilter('nicetime', [$this, 'jazykolamTime']),
        ];
    }

    public function autoT($key, ...$args)
    {
        $language = $this->grav['language'];
        return $language->translate($key);
    }

    public function jazykolamTime($date)
    {
        return $date;
    }
}
