
<?php
namespace Grav\Plugin;

use Grav\Common\Grav;
use Grav\Common\File\CompiledYamlFile;

class JazykolamTranslationManager
{
    protected Grav $grav;

    public function __construct(?Grav $grav = null)
    {
        $this->grav = $grav ?: Grav::instance();
    }

    public function getLocales(): array
    {
        $language = $this->grav['language'];
        $locales = (array)$language->getLanguages();
        if (empty($locales)) {
            $locales = [$language->getDefault() ?: 'en'];
        }
        return $locales;
    }

    public function getAllKeysForLocale(string $locale): array
    {
        $language = $this->grav['language'];
        $all = (array)$language->getTranslations();
        $keys = [];
        if (isset($all[$locale]) && is_array($all[$locale])) {
            foreach ($all[$locale] as $key => $value) {
                $keys[$key]['original'] = $value;
            }
        }
        $overrides = $this->getOverrideData($locale);
        foreach ($overrides as $key => $value) {
            if (!isset($keys[$key])) {
                $keys[$key]['original'] = '';
            }
            $keys[$key]['override'] = $value;
        }
        ksort($keys);
        return $keys;
    }

    public function getOverrideData(string $locale): array
    {
        $file = $this->getOverrideFile($locale);
        return (array)$file->content();
    }

    public function saveOverrides(string $locale, array $translations): void
    {
        $file = $this->getOverrideFile($locale);
        $data = (array)$file->content();
        foreach ($translations as $key => $value) {
            $key = trim((string)$key);
            if ($key === '') { continue; }
            $value = trim((string)$value);
            if ($value === '') { unset($data[$key]); }
            else { $data[$key] = $value; }
        }
        $file->save($data);
        $file->free();
    }

    protected function getOverrideFile(string $locale): CompiledYamlFile
    {
        $locator = $this->grav['locator'];
        $dir = $locator->findResource('user://languages', true, true);
        $path = $dir . '/jazykolam.' . $locale . '.yaml';
        return CompiledYamlFile::instance($path);
    }
}
