
## 1.0.0
- Added Export (`task:jazykolam.exportTranslations` with params `format` and `locale`).
- Admin UI buttons for quick export.
- Minor wording updates in languages.
